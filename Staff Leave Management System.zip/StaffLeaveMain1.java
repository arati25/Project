package Abc;

import java.util.Scanner;

class StaffLeaveApplication {
	String Leave_type;
	String Leave_period;
	String Work_week;
	String Holidays;
	String Emp_Leave;

	public StaffLeaveApplication() {
		super();
	}

	public StaffLeaveApplication(String leave_type, String leave_period, String work_week, String holidays,
			String emp_Leave) {
		super();
		this.Leave_type = leave_type;
		this.Leave_period = leave_period;
		this.Work_week = work_week;
		this.Holidays = holidays;
		this.Emp_Leave = emp_Leave;
	}

	public String getLeave_type() {
		return Leave_type;
	}

	public void setLeave_type(String leave_type) {
		Leave_type = leave_type;
	}

	public String getLeave_period() {
		return Leave_period;
	}

	public void setLeave_period(String leave_period) {
		Leave_period = leave_period;
	}

	public String getWork_week() {
		return Work_week;
	}

	public void setWork_week(String work_week) {
		Work_week = work_week;
	}

	public String getHolidays() {
		return Holidays;
	}

	public void setHolidays(String holidays) {
		Holidays = holidays;
	}

	public String getEmp_Leave() {
		return Emp_Leave;
	}

	public void setEmp_Leave(String emp_Leave) {
		Emp_Leave = emp_Leave;
	}

	@Override
	public String toString() {
		return "StaffLeaveApplication[Leave_type=" + Leave_type + ", Leave_period=" + Leave_period + ", Work_week="
				+ Work_week + ", Holidays=" + Holidays + ", Emp_Leave=" + Emp_Leave + "]";
	}

	void insertLeaveDetails()
	{
		Scanner sc = new Scanner(System.in);
		  System.out.println("Enter Leave_Type"); 
		  Leave_type = sc.nextLine();
		  System.out.println("Enter Leave_Period");
		  Leave_period = sc.nextLine();
		 System.out.println("Your Leave has been Applied Succesfully!!");
		 System.out.println("Leave Type : "+Leave_type);
		 System.out.println("Leave Period : "+Leave_period);
	}
}

class Registration {
	String fullName;
	String emailId;
	String UserName;
	String Password;
	String confirmpassword;

	public Registration() {
		super();
	}
	public Registration(String fullName, String emailId, String userName, String password,
			String confirmpassword) {
		super();
		this.fullName = fullName;
		this.emailId = emailId;
		this.UserName = userName;
		this.Password = password;
		this.confirmpassword = confirmpassword;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		this.UserName = userName;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		this.Password = password;
	}

	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	@Override
	public String toString() {
		return "Progra1 [fullName=" + fullName + ", emailId=" + emailId + ", userName="
				+ UserName + ", password=" + Password + ", confirmpassword=" + confirmpassword + ", getFullName()="
				+ getFullName() + ", getEmailId()=" + getEmailId() +", getUserName()=" + getUserName() + ", getPassword()=" + getPassword() + ", getConfirmpassword()="
				+ getConfirmpassword() + "]";
	}
	
	void AddRegistrationDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter full name");
		 fullName = sc.nextLine();
		System.out.println("Enter emailId");
		 emailId = sc.nextLine();
		System.out.println("Enter UserName");
		 UserName = sc.next();
		System.out.println("Enter Password");
		 Password = sc.next();
		System.out.println("Enter confirmpassword");
		 confirmpassword = sc.next();
		
	}

	void RegistrationDetail() {
		System.out.print("Full Name: " + fullName + "\n");
		System.out.print("Email Id: " + emailId + "\n");
		System.out.print("UserName: " + UserName + "\n");
		System.out.print("Password: " + Password + "\n");
		System.out.print("Confirm Password: " + confirmpassword + "\n");
		System.out.println("User Registered Succesfully!!");

	}
}

class Login {
	String UserName;
	String Password;
	
	public Login() {
		super();
	}

	public Login(String userName, String password) {
		super();
		UserName = userName;
		Password = password;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}
	
	@Override
	public String toString() {
		return "Login [UserName=" + UserName + ", Password=" + Password + "]";
	}

	void LoginDisplay()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("please enter userName");
		UserName=sc.nextLine();
		System.out.println("please enter password");
		Password=sc.nextLine();
	}

}

class staffDetails{
	StaffLeaveApplication staffDetail1 = new StaffLeaveApplication("Casual Leave", "1-Jan-2020 TO 31-Dec-2021",
			"52 weeks", "114", "8");
	StaffLeaveApplication staffDetail2 = new StaffLeaveApplication("Medical Leave", "03-feb-2020 TO 25-May-2020",
			"58 weeks", "104", "7");
	StaffLeaveApplication staffDetail3 = new StaffLeaveApplication("Annual Leave", "6-March-2021 TO 5-june-2021",
			"56 weeks", "100", "9");
	
	public staffDetails() {
		super();
	}

	void PrintEmployeeLeaveDeatils() {
		System.out.println("==============================Employee Leave Details===================");
		System.out.println(staffDetail1 + "\n");
		System.out.println(staffDetail2 + "\n");
		System.out.println(staffDetail3 + "\n");
	}

}

class staffLeaveMain1{
	private static final Object UserName = "user";
	private static final Object Password = "pass";

	public static void main(String args[]) {
		Registration reg = new Registration();
		Login login = new Login();
		staffDetails details = new staffDetails();
	StaffLeaveApplication application = new StaffLeaveApplication();
		Scanner sc = new Scanner(System.in);

		System.out.println("=================Staff Leave Manaagement=================");
		System.out.println("Enter your choice:");
		int ch = sc.nextInt();
		String choice[] = { "1.Registration", "2.Login", "3.Exit" };

		do {
			for (String s : choice)
				System.out.println(s);
			int ch1 = sc.nextInt();
			switch (ch1) {
			case 1:
				System.out.println("==================Please Enter the Registration Details:==========================");
				reg.AddRegistrationDetails();
				System.out.println("===============Registration Details:====================");
				reg.RegistrationDetail();
				break;
			case 2:
				
				login.LoginDisplay();
				reg.RegistrationDetail();
				System.err.println();
				if (reg.getUserName().equals(login.getUserName()) && reg.getPassword().equals(login.getPassword())) {
					System.out.println("Login sucessfully!!");
					details.PrintEmployeeLeaveDeatils();
					System.out.println("Apply for Leave: ");
					application.insertLeaveDetails();
				} else {
					System.out.println("Login Invalid");
				}
				//Login l = new Login(fullname, emailId, phoneNo, UserName, Password, confirmpassword);
				//l.PrintEmployeeLeaveDeatils();
				break;

			default:
				System.out.println("Enter valid choice or End");
				break;
			}
		} while (ch != 5);

	}
}
